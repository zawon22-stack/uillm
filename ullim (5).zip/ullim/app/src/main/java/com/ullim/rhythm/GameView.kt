package com.ullim.rhythm

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * 울림 — 악기 패드 리듬 게임.
 *
 * 화면에 패드 4개: 멜로디 · 하이햇 / 킥 · 스네어.
 * 분석기가 노래에서 악기별 리듬 패턴을 익히면, 다음 마디의 같은 자리에 노트가 온다.
 * 패드 둘레로 줄어드는 고리가 패드 테두리에 닿을 때 그 패드를 탭.
 * 노트가 없어도 패드는 그 악기 소리가 들릴 때마다 빛난다(분석이 잘 되는지 눈으로 확인).
 */
@SuppressLint("ViewConstructor")
class GameView(ctx: Context, private val host: Host) :
    SurfaceView(ctx), SurfaceHolder.Callback, Runnable {

    interface Host {
        fun requestCapture()
    }

    private enum class St { IDLE, LISTEN, PLAY, OVER }

    private class Note(val lane: Int, val t: Long) {
        var judged = false
    }

    private class Spark(
        var x: Float, var y: Float, val vx: Float, val vy: Float, var life: Float, val color: Int
    )

    private class RingFx(val x: Float, val y: Float, val r0: Float, var life: Float, val color: Int)
    private class Pop(val text: String, val x: Float, var y: Float, var life: Float, val color: Int)

    companion object {
        const val APPROACH = 1_000_000_000L
        const val PERFECT = 45_000_000L
        const val GREAT = 90_000_000L
        const val OK = 140_000_000L
        val NAMES = arrayOf("킥", "스네어", "하이햇", "멜로디")
        val HUES = floatArrayOf(14f, 46f, 186f, 288f)
    }

    private val lock = Any()
    @Volatile private var running = false
    private var thread: Thread? = null
    private val dp = resources.displayMetrics.density
    private val prefs = ctx.getSharedPreferences("ullim", Context.MODE_PRIVATE)
    private val rnd = Random(System.nanoTime())

    @Volatile var message: String? = null

    private var st = St.IDLE
    private var w = 1f
    private var h = 1f
    private var padR = 1f
    private val padX = FloatArray(4)
    private val padY = FloatArray(4)
    private var vizTop = 0f
    private var vizBot = 0f

    private val notes = ArrayList<Note>()
    private val sparks = ArrayList<Spark>()
    private val rings = ArrayList<RingFx>()
    private val pops = ArrayList<Pop>()
    private val press = FloatArray(4)
    private val missFlash = FloatArray(4)
    private val lastNoteT = LongArray(4)

    private var score = 0L
    private var combo = 0
    private var maxCombo = 0
    private var life = 100f
    private var best = prefs.getLong("best2", 0L)
    private var offsetMs = prefs.getInt("offset", 0)
    private var lastStep = Long.MIN_VALUE
    private var epochSeen = -1
    private var playStart = 0L
    private var overAt = 0L
    private var hitsPerfect = 0
    private var hitsTotal = 0

    private var fever = false
    private var feverHot = 0f
    private var feverCool = 0f
    private var hue = 230f
    private var flash = 0f

    private val startBtn = RectF()
    private val minusBtn = RectF()
    private val plusBtn = RectF()
    private val hsvTmp = FloatArray(3)

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
    }
    private val vig = Paint()

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    // ───────────────────────── 생명주기 / 루프 ─────────────────────────

    override fun surfaceCreated(hd: SurfaceHolder) {
        running = true
        thread = Thread(this, "game").also { it.start() }
    }

    override fun surfaceChanged(hd: SurfaceHolder, format: Int, width: Int, height: Int) {
        synchronized(lock) { layout(width.toFloat(), height.toFloat()) }
    }

    override fun surfaceDestroyed(hd: SurfaceHolder) {
        running = false
        try {
            thread?.join(500)
        } catch (_: InterruptedException) {
        }
        thread = null
    }

    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            val dt = min(0.05f, (now - last) / 1e9f)
            last = now
            val c: Canvas? = try {
                holder.lockHardwareCanvas()
            } catch (e: Exception) {
                null
            }
            if (c == null) {
                Thread.sleep(16)
                continue
            }
            try {
                synchronized(lock) {
                    update(now, dt)
                    render(c, now)
                }
            } finally {
                holder.unlockCanvasAndPost(c)
            }
        }
    }

    private fun layout(W: Float, H: Float) {
        w = W
        h = H
        padR = min(W * 0.2f, H * 0.105f)
        val cx0 = W * 0.27f
        val cx1 = W * 0.73f
        val ry0 = H * 0.53f
        val ry1 = H * 0.77f
        padX[Beat.MELODY] = cx0; padY[Beat.MELODY] = ry0
        padX[Beat.HAT] = cx1; padY[Beat.HAT] = ry0
        padX[Beat.KICK] = cx0; padY[Beat.KICK] = ry1
        padX[Beat.SNARE] = cx1; padY[Beat.SNARE] = ry1
        vizTop = 112 * dp
        vizBot = ry0 - padR - 26 * dp
        vig.shader = RadialGradient(
            W / 2, H * 0.55f, hypot(W, H) * 0.6f,
            intArrayOf(0x00000000, 0x00000000, 0xC0000000.toInt()),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        val bw = min(W * 0.62f, 260 * dp)
        val bh = 56 * dp
        startBtn.set(W / 2 - bw / 2, H * 0.56f, W / 2 + bw / 2, H * 0.56f + bh)
        val sy = H - 66 * dp
        minusBtn.set(14 * dp, sy, 14 * dp + 56 * dp, sy + 46 * dp)
        plusBtn.set(W - 14 * dp - 56 * dp, sy, W - 14 * dp, sy + 46 * dp)
    }

    // ───────────────────────── 게임 로직 ─────────────────────────

    private fun update(now: Long, dt: Float) {
        val cap = Beat.capturing
        if (!cap && (st == St.LISTEN || st == St.PLAY)) st = St.IDLE
        if (cap && st == St.IDLE) st = St.LISTEN
        if (st == St.LISTEN && Beat.locked) startPlay(now)
        if (st == St.PLAY) {
            if (Beat.locked) schedule(now)
            judgeMisses(now)
            updateFever(dt)
            if (life <= 0f) gameOver(now)
        }
        notes.removeAll { it.judged && now - it.t > 200_000_000L }

        for (i in 0 until 4) {
            Beat.live[i] *= exp(-dt * 7f)
            press[i] *= exp(-dt * 14f)
            missFlash[i] *= exp(-dt * 5f)
        }
        val it1 = sparks.iterator()
        while (it1.hasNext()) {
            val s = it1.next()
            s.x += s.vx * dt
            s.y += s.vy * dt
            s.life -= dt * 1.8f
            if (s.life <= 0f) it1.remove()
        }
        val it2 = rings.iterator()
        while (it2.hasNext()) {
            val r = it2.next()
            r.life -= dt * 2.6f
            if (r.life <= 0f) it2.remove()
        }
        val it3 = pops.iterator()
        while (it3.hasNext()) {
            val p = it3.next()
            p.y -= 34 * dp * dt
            p.life -= dt * 1.4f
            if (p.life <= 0f) it3.remove()
        }
        flash *= exp(-dt * 5f)
        hue = (hue + dt * (if (fever) 40f else 4f)) % 360f
    }

    private fun startPlay(now: Long) {
        notes.clear()
        score = 0
        combo = 0
        maxCombo = 0
        life = 100f
        hitsPerfect = 0
        hitsTotal = 0
        fever = false
        lastStep = Long.MIN_VALUE
        epochSeen = -1
        lastNoteT.fill(0L)
        playStart = now
        st = St.PLAY
    }

    private fun gameOver(now: Long) {
        st = St.OVER
        overAt = now
        if (score > best) {
            best = score
            prefs.edit().putLong("best2", best).apply()
        }
    }

    /** 앞으로 APPROACH 안에 올 16분음표 칸마다, 익힌 패턴대로 노트를 만든다 */
    private fun schedule(now: Long) {
        val g = Beat.grid
        val off = offsetMs * 1_000_000L
        if (epochSeen != Beat.epoch || lastStep == Long.MIN_VALUE) {
            epochSeen = Beat.epoch
            lastStep = floor(g.stepAt(now - off + APPROACH / 2)).toLong()
        }
        val until = floor(g.stepAt(now - off + APPROACH)).toLong()
        var s = lastStep + 1
        while (s <= until) {
            placeStep(s, g.timeOfStep(s) + off, g.periodNs / 4)
            s++
        }
        if (until > lastStep) lastStep = until
    }

    private val candLane = IntArray(4)
    private val candScore = FloatArray(4)

    private fun placeStep(s: Long, tn: Long, stepNs: Long) {
        val learning = Pattern.learned < 32
        var nc = 0
        if (learning) {
            // 아직 패턴을 모를 때: 정박에 킥만
            if (Math.floorMod(s, 4L) == 0L) {
                candLane[0] = Beat.KICK
                candScore[0] = 1f
                nc = 1
            }
        } else {
            for (i in 0 until 4) {
                val p = Pattern.p(i, s)
                val th = when (i) {
                    Beat.HAT -> 0.55f
                    Beat.SNARE -> 0.5f
                    else -> 0.45f
                }
                if (p <= th) continue
                // 하이햇은 기본적으로 8분음표까지만 (너무 촘촘하면 손이 못 따라감)
                if (i == Beat.HAT && Math.floorMod(s, 2L) == 1L && !(combo >= 40 && stepNs > 120_000_000L)) continue
                val prio = when (i) {
                    Beat.KICK -> 1.3f
                    Beat.SNARE -> 1.2f
                    Beat.MELODY -> 1.1f
                    else -> 0.8f
                }
                candLane[nc] = i
                candScore[nc] = p * prio
                nc++
            }
        }
        // 스네어와 멜로디가 같은 칸이면 섞여 들린 것일 수 있어 하나만
        val si = (0 until nc).firstOrNull { candLane[it] == Beat.SNARE }
        val mi = (0 until nc).firstOrNull { candLane[it] == Beat.MELODY }
        if (si != null && mi != null) {
            if (candScore[si] >= candScore[mi]) candScore[mi] = -1f else candScore[si] = -1f
        }
        // 한 칸에 최대 2개, 같은 패드는 너무 붙지 않게
        val minGap = max(130_000_000L, stepNs)
        var placed = 0
        while (placed < 2) {
            var bi = -1
            for (k in 0 until nc) if (candScore[k] > 0f && (bi < 0 || candScore[k] > candScore[bi])) bi = k
            if (bi < 0) break
            val lane = candLane[bi]
            candScore[bi] = -1f
            if (tn - lastNoteT[lane] < minGap) continue
            notes.add(Note(lane, tn))
            lastNoteT[lane] = tn
            placed++
        }
    }

    private fun judgeMisses(now: Long) {
        for (n in notes) {
            if (n.judged || now <= n.t + OK) continue
            n.judged = true
            combo = 0
            life -= 7f
            missFlash[n.lane] = 1f
            pop("놓침", n.lane, Color.rgb(255, 120, 140))
        }
    }

    private fun updateFever(dt: Float) {
        val e = Beat.level / (Beat.levelAvg + 1e-6f)
        if (!fever) {
            feverHot = if (e > 1.25f && Beat.locked) feverHot + dt else 0f
            if (feverHot > 0.8f) {
                fever = true
                feverCool = 0f
                flash = 1f
                pops.add(Pop("DROP!", w / 2, (vizTop + vizBot) / 2, 1.6f, Color.WHITE))
            }
        } else {
            feverCool = if (e < 1.0f) feverCool + dt else 0f
            if (feverCool > 1.2f) fever = false
        }
    }

    private fun hit(lane: Int, t: Long) {
        var target: Note? = null
        var bestD = Long.MAX_VALUE
        for (n in notes) {
            if (n.lane != lane || n.judged) continue
            val d = abs(t - n.t)
            if (d < bestD) {
                bestD = d
                target = n
            }
        }
        val n = target ?: return
        if (bestD > OK) return
        n.judged = true
        val (base, label, gain) = when {
            bestD <= PERFECT -> Triple(300, "완벽", 2f)
            bestD <= GREAT -> Triple(200, "좋아", 1.5f)
            else -> Triple(100, "괜찮아", 0.5f)
        }
        if (bestD <= PERFECT) hitsPerfect++
        hitsTotal++
        combo++
        maxCombo = max(maxCombo, combo)
        score += (base * (1 + combo / 25) * (if (fever) 2 else 1)).toLong()
        life = min(100f, life + gain)
        val col = laneColor(lane, 1f)
        rings.add(RingFx(padX[lane], padY[lane], padR, 1f, col))
        burst(padX[lane], padY[lane], col, if (bestD <= PERFECT) 16 else 9)
        pop(label, lane, if (bestD <= PERFECT) Color.WHITE else laneColor(lane, 0.6f))
        if (combo % 50 == 0) pops.add(Pop("콤보 $combo", w / 2, (vizTop + vizBot) / 2, 1.4f, Color.WHITE))
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    // ───────────────────────── 입력 ─────────────────────────

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val am = e.actionMasked
        if (am != MotionEvent.ACTION_DOWN && am != MotionEvent.ACTION_POINTER_DOWN) return true
        val tNs = System.nanoTime() - (SystemClock.uptimeMillis() - e.eventTime) * 1_000_000L
        val i = e.actionIndex
        val x = e.getX(i)
        val y = e.getY(i)
        synchronized(lock) { down(x, y, tNs) }
        return true
    }

    private fun down(x: Float, y: Float, t: Long) {
        when (st) {
            St.IDLE -> {
                if (startBtn.contains(x, y)) host.requestCapture()
                return
            }
            St.OVER -> {
                if (t - overAt > 900_000_000L) {
                    if (Beat.locked) startPlay(System.nanoTime()) else st = St.LISTEN
                }
                return
            }
            else -> {}
        }
        if (minusBtn.contains(x, y)) {
            setOffset(offsetMs - 10)
            return
        }
        if (plusBtn.contains(x, y)) {
            setOffset(offsetMs + 10)
            return
        }
        var lane = -1
        var bd = Float.MAX_VALUE
        for (k in 0 until 4) {
            val d = hypot(x - padX[k], y - padY[k])
            if (d < padR * 1.45f && d < bd) {
                bd = d
                lane = k
            }
        }
        if (lane < 0) return
        press[lane] = 1f
        if (st == St.PLAY) hit(lane, t)
    }

    private fun setOffset(v: Int) {
        offsetMs = v.coerceIn(-400, 400)
        prefs.edit().putInt("offset", offsetMs).apply()
    }

    // ───────────────────────── 그리기 ─────────────────────────

    private fun render(c: Canvas, now: Long) {
        val off = offsetMs * 1_000_000L
        var pulse = 0f
        if (Beat.locked) {
            val g = Beat.grid
            val lb = g.beatAtOrAfter(now - off - g.periodNs + 1) + off
            pulse = exp(-(now - lb) / 1.1e8).toFloat()
        }

        c.drawColor(hsv(hue, if (fever) 0.75f else 0.6f, 0.10f + (if (fever) 0.08f else 0.035f) * pulse))
        c.drawRect(0f, 0f, w, h, vig)
        if (flash > 0.02f) {
            fill.color = Color.argb((flash * 110).toInt(), 255, 255, 255)
            c.drawRect(0f, 0f, w, h, fill)
        }

        if (st == St.IDLE) {
            drawIdle(c)
            return
        }

        drawSpectrum(c, pulse)
        for (k in 0 until 4) drawPad(c, k)
        drawNotes(c, now)
        drawFx(c)
        drawHud(c, now)
        drawSync(c)
        if (st == St.OVER) drawOver(c, now)
    }

    private fun drawSpectrum(c: Canvas, pulse: Float) {
        val n = Beat.BANDS
        val mid = (vizTop + vizBot) / 2
        val maxH = (vizBot - vizTop) / 2
        if (maxH < 10 * dp) return
        val bw = w / n
        stroke.strokeWidth = bw * 0.55f
        for (i in 0 until n) {
            val v = Beat.spec[i]
            val x = bw * (i + 0.5f)
            val hh = 2 * dp + v * maxH * (0.85f + 0.15f * pulse)
            stroke.color = hsv(hue + i * 3f, 0.45f, 1f, (60 + 150 * v).toInt())
            c.drawLine(x, mid - hh, x, mid + hh, stroke)
        }
    }

    private fun drawPad(c: Canvas, k: Int) {
        val x = padX[k]
        val y = padY[k]
        val lv = Beat.live[k]
        val r = padR * (1f - 0.07f * press[k])
        // 그 악기 소리가 들릴 때 번지는 빛
        if (lv > 0.03f) {
            fill.color = laneColor(k, 1f, (lv * 110).toInt())
            c.drawCircle(x, y, r * (1f + 0.22f * lv), fill)
        }
        fill.color = hsv(HUES[k], 0.55f, 0.17f + 0.12f * press[k])
        c.drawCircle(x, y, r, fill)
        if (missFlash[k] > 0.03f) {
            fill.color = Color.argb((missFlash[k] * 90).toInt(), 255, 60, 80)
            c.drawCircle(x, y, r, fill)
        }
        stroke.strokeWidth = 3 * dp
        stroke.color = laneColor(k, 1f, 200)
        c.drawCircle(x, y, r, stroke)
        text.textSize = 17 * dp
        text.color = laneColor(k, 0.35f, 220)
        c.drawText(NAMES[k], x, y + 6 * dp, text)
        text.color = Color.WHITE
    }

    private fun drawNotes(c: Canvas, now: Long) {
        for (n in notes) {
            if (n.judged) continue
            val k = (n.t - now).toFloat() / APPROACH
            if (k > 1.05f) continue
            val kk = max(k, -0.2f)
            val r = padR * (1f + 1.5f * kk)
            val a = ((1f - kk).coerceIn(0f, 1f) * 255).toInt().coerceAtLeast(70)
            stroke.strokeWidth = (4 + 3 * (1f - kk.coerceIn(0f, 1f))) * dp
            stroke.color = laneColor(n.lane, 0.6f, a)
            c.drawCircle(padX[n.lane], padY[n.lane], r, stroke)
            if (k < 0.18f) {
                fill.color = laneColor(n.lane, 1f, ((0.18f - max(k, 0f)) / 0.18f * 70).toInt())
                c.drawCircle(padX[n.lane], padY[n.lane], padR, fill)
            }
        }
    }

    private fun drawFx(c: Canvas) {
        for (r in rings) {
            stroke.strokeWidth = 5 * dp * r.life
            stroke.color = r.color
            stroke.alpha = (r.life * 255).toInt().coerceIn(0, 255)
            c.drawCircle(r.x, r.y, r.r0 * (1f + 0.5f * (1f - r.life)), stroke)
        }
        for (s in sparks) {
            fill.color = s.color
            fill.alpha = (s.life.coerceIn(0f, 1f) * 255).toInt()
            c.drawCircle(s.x, s.y, 3 * dp, fill)
        }
        for (p in pops) {
            text.textSize = (if (p.text == "DROP!") 40 else 19) * dp
            text.color = p.color
            text.alpha = (p.life.coerceIn(0f, 1f) * 255).toInt()
            c.drawText(p.text, p.x, p.y, text)
        }
        text.alpha = 255
        text.color = Color.WHITE
    }

    private fun drawHud(c: Canvas, now: Long) {
        val top = 40 * dp
        val pad = 20 * dp

        text.textAlign = Paint.Align.RIGHT
        text.textSize = 15 * dp
        text.alpha = 210
        val status = when {
            Beat.silent -> "소리 없음"
            Beat.locked -> "♪ ${Beat.bpm()} BPM" + (if (Beat.source == 2) " · 예비 입력" else "")
            else -> "박자 찾는 중"
        }
        c.drawText(status, w - pad, top + 14 * dp, text)
        text.alpha = 255

        if (st == St.PLAY || st == St.OVER) {
            text.textAlign = Paint.Align.LEFT
            text.textSize = 30 * dp
            c.drawText(String.format("%,d", score), pad, top + 24 * dp, text)
            text.textSize = 15 * dp
            text.alpha = 210
            val sub = (if (combo > 1) "콤보 $combo" else "") + (if (fever) "   피버 ×2" else "")
            c.drawText(sub, pad, top + 48 * dp, text)
            text.alpha = 255

            val bw = min(w * 0.36f, 150 * dp)
            val bx = w - pad - bw
            val by = top + 26 * dp
            fill.color = Color.argb(50, 255, 255, 255)
            c.drawRoundRect(bx, by, bx + bw, by + 7 * dp, 4 * dp, 4 * dp, fill)
            fill.color = if (life > 35f) Color.rgb(120, 235, 200) else Color.rgb(255, 90, 110)
            c.drawRoundRect(bx, by, bx + bw * (life / 100f).coerceIn(0f, 1f), by + 7 * dp, 4 * dp, 4 * dp, fill)
        }
        text.textAlign = Paint.Align.CENTER

        val my = (vizTop + vizBot) / 2
        when (st) {
            St.LISTEN -> {
                if (Beat.silent) {
                    line(c, "음악을 틀어 주세요", my - 8 * dp, 21f, 255)
                    line(c, "다른 앱에서 나오는 소리를 그대로 들어요", my + 18 * dp, 13f, 180)
                } else {
                    line(c, "박자를 듣는 중…", my - 8 * dp, 21f, 255)
                    line(c, "패드가 악기 소리에 맞춰 빛나요", my + 18 * dp, 13f, 180)
                }
                val err = Beat.error
                if (err != null) line(c, err, my + 40 * dp, 13f, 220)
            }
            St.PLAY -> {
                if (!Beat.locked) {
                    line(c, "박자를 다시 찾는 중…", my, 16f, 220)
                } else if (Pattern.learned < 32) {
                    line(c, "노래 패턴을 익히는 중…", my - 6 * dp, 17f, 235)
                    line(c, "고리가 패드 테두리에 닿을 때 탭!", my + 18 * dp, 13f, 190)
                } else if (now - playStart < 9_000_000_000L) {
                    line(c, "고리가 패드 테두리에 닿을 때 탭!", my, 14f, 170)
                }
            }
            else -> {}
        }
    }

    private fun drawIdle(c: Canvas) {
        val ty = h * 0.3f
        line(c, "울림", ty, 56f, 255)
        line(c, "지금 듣는 노래의 킥 · 스네어 · 하이햇 · 멜로디를", ty + 40 * dp, 14f, 210)
        line(c, "패드로 따라 치는 리듬 게임", ty + 62 * dp, 14f, 210)

        fill.color = hsv(160f, 0.5f, 0.95f)
        c.drawRoundRect(startBtn, 28 * dp, 28 * dp, fill)
        text.color = Color.rgb(16, 28, 34)
        text.textSize = 19 * dp
        c.drawText("시작하기", startBtn.centerX(), startBtn.centerY() + 7 * dp, text)
        text.color = Color.WHITE

        val y = startBtn.bottom + 32 * dp
        line(c, "공유 창이 뜨면 '전체 화면'으로 시작하세요", y, 13f, 170)
        line(c, "소리는 분석에만 쓰고 저장하지 않아요", y + 20 * dp, 13f, 130)
        val msg = message ?: Beat.error
        if (msg != null) {
            text.color = Color.rgb(255, 150, 165)
            line(c, msg, startBtn.top - 20 * dp, 14f, 255)
            text.color = Color.WHITE
        }
    }

    private fun drawOver(c: Canvas, now: Long) {
        fill.color = Color.argb(185, 0, 0, 0)
        c.drawRect(0f, 0f, w, h, fill)
        val y = h * 0.34f
        line(c, "라이프가 다 떨어졌어요", y, 22f, 255)
        line(c, String.format("%,d", score), y + 62 * dp, 48f, 255)
        line(c, "최고 ${String.format("%,d", best)}  ·  최대 콤보 $maxCombo", y + 98 * dp, 15f, 210)
        val acc = if (hitsTotal > 0) hitsPerfect * 100 / hitsTotal else 0
        line(c, "완벽 비율 $acc%", y + 122 * dp, 15f, 180)
        if (now - overAt > 900_000_000L) line(c, "탭해서 다시 시작", y + 180 * dp, 17f, 235)
    }

    private fun drawSync(c: Canvas) {
        fill.color = Color.argb(36, 255, 255, 255)
        c.drawRoundRect(minusBtn, 14 * dp, 14 * dp, fill)
        c.drawRoundRect(plusBtn, 14 * dp, 14 * dp, fill)
        text.textSize = 24 * dp
        text.alpha = 230
        c.drawText("−", minusBtn.centerX(), minusBtn.centerY() + 8 * dp, text)
        c.drawText("+", plusBtn.centerX(), plusBtn.centerY() + 8 * dp, text)
        val sign = if (offsetMs > 0) "+" else ""
        line(c, "싱크 $sign${offsetMs}ms", minusBtn.centerY() - 1 * dp, 14f, 210)
        line(c, "노트가 소리보다 빠르면 +", minusBtn.centerY() + 17 * dp, 11.5f, 140)
    }

    private fun line(c: Canvas, s: String, y: Float, sizeDp: Float, alpha: Int) {
        text.textAlign = Paint.Align.CENTER
        text.textSize = sizeDp * dp
        text.alpha = alpha
        c.drawText(s, w / 2, y, text)
        text.alpha = 255
    }

    // ───────────────────────── 도우미 ─────────────────────────

    private fun burst(x: Float, y: Float, color: Int, count: Int) {
        repeat(count) {
            val a = rnd.nextFloat() * 6.2832f
            val sp = (80 + rnd.nextFloat() * 200) * dp
            sparks.add(
                Spark(
                    x, y, kotlin.math.cos(a) * sp, kotlin.math.sin(a) * sp,
                    0.5f + rnd.nextFloat() * 0.5f, color
                )
            )
        }
    }

    private fun pop(s: String, lane: Int, color: Int) {
        pops.add(Pop(s, padX[lane], padY[lane] - padR - 10 * dp, 1f, color))
    }

    private fun laneColor(lane: Int, sat: Float, a: Int = 255): Int = hsv(HUES[lane], sat, 1f, a)

    private fun hsv(hh: Float, s: Float, v: Float, a: Int = 255): Int {
        hsvTmp[0] = ((hh % 360f) + 360f) % 360f
        hsvTmp[1] = s
        hsvTmp[2] = v
        return Color.HSVToColor(a.coerceIn(0, 255), hsvTmp)
    }

    @Suppress("unused")
    private fun dist(a: Float, b: Float) = sqrt(a * a + b * b)
}
