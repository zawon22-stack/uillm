package com.ullim.rhythm

import android.media.audiofx.Visualizer
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * 예비 소리 입력: 폰 전체 출력(세션 0)을 Visualizer로 읽는다.
 * 스포티파이처럼 캡처를 막아 둔 앱도 음악 시각화 앱처럼 박자를 들을 수 있다.
 * 8비트 파형 스냅샷을 주기적으로 읽어 '새로 들어온 만큼'만 이어 붙여 연속 신호처럼 만든다.
 */
class VizSource private constructor(private val v: Visualizer) {

    /** 출력 믹스의 샘플레이트(Hz) */
    val rate: Int = (v.samplingRate / 1000).let { if (it in 8000..192000) it else 48000 }
    private val wave = ByteArray(v.captureSize)
    private var lastNs = 0L

    /** out에 새 샘플을 채우고 개수를 돌려준다 */
    fun pull(out: ShortArray, now: Long): Int {
        val ok = try {
            v.getWaveForm(wave) == Visualizer.SUCCESS
        } catch (e: Exception) {
            false
        }
        if (!ok) return 0
        val dt = if (lastNs == 0L) 0.012 else (now - lastNs) / 1e9
        lastNs = now
        val n = min(out.size, min(wave.size, (dt * rate).roundToInt()))
        val start = wave.size - n
        for (i in 0 until n) {
            out[i] = (((wave[start + i].toInt() and 0xFF) - 128) shl 8).toShort()
        }
        return n
    }

    fun release() {
        try {
            v.enabled = false
        } catch (_: Exception) {
        }
        v.release()
    }

    companion object {
        fun create(): VizSource? = try {
            val v = Visualizer(0)
            v.enabled = false
            v.captureSize = Visualizer.getCaptureSizeRange()[1]
            v.scalingMode = Visualizer.SCALING_MODE_NORMALIZED
            v.enabled = true
            VizSource(v)
        } catch (e: Throwable) {
            null
        }
    }
}
