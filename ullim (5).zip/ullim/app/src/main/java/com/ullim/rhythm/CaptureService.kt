package com.ullim.rhythm

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import kotlin.math.max

/**
 * 다른 앱에서 재생 중인 소리를 받아(AudioPlaybackCapture) 분석기에 넘기는 포그라운드 서비스.
 * 소리는 메모리에서 바로 분석만 하고 저장하지 않는다.
 */
class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "listen"
        private const val SAMPLE_RATE = 44100
    }

    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    @Volatile private var running = false
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (projection != null) return START_NOT_STICKY

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.let { dataOf(it) }
        if (data == null) {
            fail("화면 공유 허용 정보를 받지 못했어요")
            return START_NOT_STICKY
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val mp = try {
            mpm.getMediaProjection(code, data)
        } catch (e: Exception) {
            null
        }
        if (mp == null) {
            fail("오디오 캡처를 시작하지 못했어요")
            return START_NOT_STICKY
        }
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, Handler(Looper.getMainLooper()))
        startCapture(mp)
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun dataOf(intent: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent.getParcelableExtra(EXTRA_DATA)

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "박자 듣기", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("울림")
            .setContentText("재생 중인 음악의 박자를 듣고 있어요")
            .setSmallIcon(R.drawable.ic_note)
            .setOngoing(true)
            .build()
        startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    @SuppressLint("MissingPermission") // RECORD_AUDIO는 MainActivity에서 먼저 받는다
    private fun startCapture(mp: MediaProjection) {
        val cfg = AudioPlaybackCaptureConfiguration.Builder(mp)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val rec = try {
            AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(max(minBuf, 8192))
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
        } catch (e: Exception) {
            null
        }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
            rec?.release()
            fail("이 기기에서 오디오 캡처를 열지 못했어요")
            return
        }
        record = rec
        running = true
        rec.startRecording()
        Beat.error = null
        Beat.capturing = true

        worker = Thread({
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val capAnalyzer = Analyzer(SAMPLE_RATE)
            val buf = ShortArray(512)
            // 예비 입력(Visualizer): 캡처를 막은 앱(스포티파이 등)용
            val viz = VizSource.create()
            val vizAnalyzer = viz?.let { Analyzer(it.rate) }
            val vbuf = ShortArray(4096)
            var capLoudAt = 0L
            try {
                while (running) {
                    val r = rec.read(buf, 0, buf.size) // 약 11ms마다 돌아온다 → 루프 박자
                    if (r < 0) break
                    val now = System.nanoTime()
                    if (r > 0 && loud(buf, r)) capLoudAt = now
                    val capAlive = now - capLoudAt < 2_000_000_000L
                    if (capAlive || viz == null || vizAnalyzer == null) {
                        Beat.source = if (capAlive) 1 else 0
                        if (r > 0) capAnalyzer.feed(buf, r, now)
                    } else {
                        val n = viz.pull(vbuf, now)
                        Beat.source = 2
                        if (n > 0) vizAnalyzer.feed(vbuf, n, now)
                    }
                }
            } finally {
                viz?.release()
            }
        }, "audio-capture").also { it.start() }
    }

    private fun loud(b: ShortArray, n: Int): Boolean {
        var peak = 0
        for (i in 0 until n) {
            val v = kotlin.math.abs(b[i].toInt())
            if (v > peak) peak = v
        }
        return peak > 60
    }

    private fun fail(msg: String) {
        Beat.error = msg
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        try {
            worker?.join(300)
        } catch (_: InterruptedException) {
        }
        record?.let {
            try {
                it.stop()
            } catch (_: Exception) {
            }
            it.release()
        }
        record = null
        val mp = projection
        projection = null
        mp?.stop()
        Beat.capturing = false
        Beat.locked = false
        super.onDestroy()
    }
}
