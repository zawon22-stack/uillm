package com.ullim.rhythm

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.sqrt

/** 박자 격자. 한 번에 통째로 바꿔서 게임 스레드가 어긋난 값을 읽지 않게 한다. */
class Grid(val anchorNs: Long, val periodNs: Long, val anchorIdx: Long) {
    /** 시각 t의 16분음표 위치(실수). 4 = 한 박 */
    fun stepAt(t: Long): Double = ((t - anchorNs).toDouble() / periodNs + anchorIdx) * 4.0
    fun timeOfStep(s: Long): Long = anchorNs + ((s / 4.0 - anchorIdx) * periodNs).roundToLong()
    fun beatAtOrAfter(t: Long): Long {
        val k = ceil((t - anchorNs).toDouble() / periodNs).toLong()
        return anchorNs + k * periodNs
    }
}

/**
 * 오디오 스레드(분석)와 게임 스레드(화면)가 함께 보는 공유 상태.
 * 모든 시간은 System.nanoTime() 기준.
 */
object Beat {
    const val BANDS = 40
    const val KICK = 0
    const val SNARE = 1
    const val HAT = 2
    const val MELODY = 3

    @Volatile var capturing = false
    /** 0 = 소리 없음, 1 = 오디오 캡처, 2 = 예비 입력(Visualizer) */
    @Volatile var source = 0
    @Volatile var error: String? = null
    @Volatile var locked = false
    @Volatile var silent = true
    @Volatile var grid = Grid(0L, 500_000_000L, 0L)
    /** 박자를 새로 잡을 때마다 1씩 오른다 (패턴 기억 초기화 신호) */
    @Volatile var epoch = 0
    @Volatile var confidence = 0f

    @Volatile var level = 0f
    @Volatile var levelAvg = 0.02f

    /** 0..1 로 정규화된 스펙트럼 (시각 효과용) */
    val spec = FloatArray(BANDS)
    /** 악기별로 '방금 들렸음' 표시. 분석기가 1로 올리고 게임이 줄인다 */
    val live = FloatArray(4)

    fun bpm(): Int = (60e9 / grid.periodNs).roundToInt()
}

/**
 * 마디 패턴 기억. 노래는 같은 리듬이 반복되니까
 * 지난 마디(16칸)와 지난 4마디(64칸)에서 악기마다 어느 칸에 소리가 났는지 기억했다가
 * 다음 마디를 예측한다. 한 번만 난 잡음은 금방 잊힌다.
 */
object Pattern {
    val m16 = Array(4) { FloatArray(16) }
    val m64 = Array(4) { FloatArray(64) }
    @Volatile var learned = 0

    fun p(inst: Int, step: Long): Float =
        max(m16[inst][Math.floorMod(step, 16L).toInt()], m64[inst][Math.floorMod(step, 64L).toInt()])

    fun reset() {
        for (i in 0 until 4) {
            m16[i].fill(0f)
            m64[i].fill(0f)
        }
        learned = 0
    }
}

/**
 * 실시간 분석기.
 * - 템포/박자: 스펙트럴 플럭스 자기상관 + 저음 가중 콤 필터 + 예측 시계 보정
 * - 악기 나누기: 최근 소리의 중앙값(지속음)을 빼서 '타격음'만 남기고,
 *   저음=킥, 중음 잡음=스네어/클랩, 초고음=하이햇, 음정 있는 새 소리=멜로디(보컬 포함)
 * - 찾은 소리를 16분음표 칸에 맞춰 Pattern에 기록
 */
class Analyzer(private val sr: Int) {
    private val n = 1024
    private val hop = 512
    private val half = n / 2
    private val fps = sr.toDouble() / hop
    private val binHz = sr.toDouble() / n

    private val ring = FloatArray(n)
    private var w = 0
    private var sinceHop = 0
    private val win = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / (n - 1))).toFloat() }
    private val re = FloatArray(n)
    private val im = FloatArray(n)
    private val cosT = FloatArray(n / 2) { cos(2.0 * PI * it / n).toFloat() }
    private val sinT = FloatArray(n / 2) { (-sin(2.0 * PI * it / n)).toFloat() }
    private val rev = IntArray(n)
    private val prev = FloatArray(half)
    private val lm = FloatArray(half)

    // 지속음 추정용: 최근 8프레임 로그 스펙트럼
    private val histN = 8
    private val hist = Array(histN) { FloatArray(half) }
    private var histPos = 0
    private var histCount = 0
    private val perc = FloatArray(half)
    private val tmp8 = FloatArray(histN)
    private val tmpBand = FloatArray(half)
    private val melTop = FloatArray(6)

    // 주파수 대역(빈 번호)
    private fun bin(hz: Double) = min(half - 2, max(1, (hz / binHz).roundToInt()))
    private val kLo = bin(40.0); private val kHi = max(kLo + 1, bin(135.0))
    private val lmLo = bin(215.0); private val lmHi = bin(1450.0)
    private val sLo = bin(1500.0); private val sHi = bin(5000.0)
    private val hLo = bin(8000.0); private val hHi = bin(16000.0)
    private val mLo = bin(215.0); private val mHi = bin(4000.0)

    // 악기별 온셋 검출 상태
    private val avg = FloatArray(4)
    private val dev = FloatArray(4)
    private val z0 = FloatArray(4)   // 이번 프레임
    private val z1 = FloatArray(4)   // 1프레임 전
    private val z2 = FloatArray(4)   // 2프레임 전
    private var t1 = 0L
    private val lastOnset = LongArray(4)
    private val refrNs = longArrayOf(80_000_000L, 80_000_000L, 60_000_000L, 80_000_000L)
    private val hitRing = Array(4) { LongArray(16) { Long.MIN_VALUE } }
    private val hitPos = IntArray(4)
    private var lastFinal = Long.MIN_VALUE
    private var seenEpoch = -1

    // 스펙트럼 시각화
    private val bandLo = IntArray(Beat.BANDS)
    private val bandHi = IntArray(Beat.BANDS)
    private val bandTmp = FloatArray(Beat.BANDS)
    private var specPeak = 1f

    // 템포 추정
    private val envLen = 600 // 약 7초
    private val env = FloatArray(envLen)
    private val envLow = FloatArray(envLen)
    private val envT = LongArray(envLen)
    private var envPos = 0
    private var envCount = 0
    private var frames = 0
    private var quiet = 0
    private var candNs = 0.0
    private var agree = 0
    private var mismatch = 0
    private var weak = 0
    private val halfWinNs = (n / 2 * 1e9 / sr).toLong()

    init {
        val bits = Integer.numberOfTrailingZeros(n)
        for (i in 0 until n) {
            var x = i
            var r = 0
            repeat(bits) {
                r = (r shl 1) or (x and 1)
                x = x shr 1
            }
            rev[i] = r
        }
        for (b in 0 until Beat.BANDS) {
            val f0 = 40.0 * (12000.0 / 40.0).pow(b.toDouble() / Beat.BANDS)
            val f1 = 40.0 * (12000.0 / 40.0).pow((b + 1).toDouble() / Beat.BANDS)
            val lo = min(max(1, (f0 / binHz).toInt()), half - 2)
            bandLo[b] = lo
            bandHi[b] = max(lo + 1, min(half, (f1 / binHz).toInt()))
        }
    }

    /** endNs = 이 버퍼의 마지막 샘플을 받은 시각 */
    fun feed(buf: ShortArray, count: Int, endNs: Long) {
        for (i in 0 until count) {
            ring[w] = buf[i] / 32768f
            w = (w + 1) % n
            if (++sinceHop >= hop) {
                sinceHop = 0
                val t = endNs - ((count - 1 - i) * 1e9 / sr).toLong() - halfWinNs
                frame(t)
            }
        }
    }

    private fun frame(t: Long) {
        var sq = 0f
        for (i in 0 until n) {
            val s = ring[(w + i) % n]
            sq += s * s
            val j = rev[i]
            re[j] = s * win[i]
            im[j] = 0f
        }
        fft()
        val rms = sqrt(sq / n)

        // 로그 크기, 전체 플럭스(템포용), 저음 플럭스(위상용), 멜로디 후보
        var flux = 0f
        var lowFlux = 0f
        for (k in 1 until half) {
            val mg = sqrt(re[k] * re[k] + im[k] * im[k])
            lm[k] = ln(1f + 50f * mg)
        }
        var melTot = 0f
        melTop.fill(0f)
        for (k in 1 until half) {
            val d = lm[k] - prev[k]
            if (d > 0f) {
                flux += d
                if (k <= 10) lowFlux += d
            }
            if (k in mLo..mHi) {
                // 음 흔들림(비브라토)에 덜 민감한 플럭스 + 스펙트럼 봉우리만
                val pm = max(prev[k - 1], max(prev[k], prev[k + 1]))
                val dm = lm[k] - pm
                if (dm > 0f) {
                    melTot += dm
                    if (lm[k] > lm[k - 1] && lm[k] > lm[k + 1]) insertTop(dm)
                }
            }
        }
        var top = 0f
        for (v in melTop) top += v
        val melody = top * (top / (melTot + 1e-6f))

        // 지속음(최근 8프레임 중앙값)을 빼서 타격음만
        if (histCount >= histN) {
            for (k in 1 until min(half, hHi + 1)) {
                for (h in 0 until histN) tmp8[h] = hist[h][k]
                tmp8.sort()
                perc[k] = max(0f, lm[k] - tmp8[histN / 2])
            }
        } else {
            perc.fill(0f)
        }
        System.arraycopy(lm, 0, hist[histPos], 0, half)
        histPos = (histPos + 1) % histN
        histCount++
        System.arraycopy(lm, 0, prev, 0, half)

        var low = 0f
        for (k in kLo..kHi) low += perc[k]
        low /= (kHi - kLo + 1)
        val lowMid = median(lmLo, lmHi)
        val mid = median(sLo, sHi)
        val high = median(hLo, hHi)
        var logSum = 0.0
        var linSum = 0.0
        for (k in sLo..sHi) {
            val v = perc[k] + 1e-3f
            logSum += ln(v.toDouble())
            linSum += v
        }
        val cnt = sHi - sLo + 1
        val flat = (exp(logSum / cnt) / (linSum / cnt)).toFloat()

        val sig0 = low
        val sig1 = max(0f, mid - 1.2f * high) * flat
        val sig2 = max(0f, high - 0.6f * max(mid, lowMid))
        val sig3 = melody
        detectOnsets(t, sig0, sig1, sig2, sig3)

        // 시각화용 스펙트럼
        var peak = 0f
        for (b in 0 until Beat.BANDS) {
            var s = 0f
            for (k in bandLo[b] until bandHi[b]) s += lm[k]
            s /= (bandHi[b] - bandLo[b])
            bandTmp[b] = s
            if (s > peak) peak = s
        }
        specPeak = max(peak, specPeak * 0.995f)
        for (b in 0 until Beat.BANDS) {
            val v = (bandTmp[b] / (specPeak + 1e-6f)).coerceIn(0f, 1f)
            val v2 = v * v
            Beat.spec[b] = if (v2 > Beat.spec[b]) v2 else Beat.spec[b] * 0.88f + v2 * 0.12f
        }

        Beat.level = Beat.level * 0.9f + rms * 0.1f
        Beat.levelAvg = Beat.levelAvg * 0.997f + rms * 0.003f

        // 무음 감지
        if (rms < 0.0015f) quiet++ else quiet = 0
        val nowSilent = quiet > fps * 1.2
        if (nowSilent && !Beat.silent) {
            Beat.locked = false
            agree = 0
            envCount = 0
        }
        Beat.silent = nowSilent
        if (nowSilent) return

        env[envPos] = flux
        envLow[envPos] = lowFlux
        envT[envPos] = t
        envPos = (envPos + 1) % envLen
        envCount++
        if (++frames % 15 == 0 && envCount >= fps * 3) estimate()
        if (Beat.locked) learnPattern(t)
    }

    private fun insertTop(v: Float) {
        var mi = 0
        for (i in 1 until melTop.size) if (melTop[i] < melTop[mi]) mi = i
        if (v > melTop[mi]) melTop[mi] = v
    }

    private fun median(lo: Int, hi: Int): Float {
        val c = hi - lo + 1
        System.arraycopy(perc, lo, tmpBand, 0, c)
        java.util.Arrays.sort(tmpBand, 0, c)
        return tmpBand[c / 2]
    }

    // ───────── 악기별 온셋 ─────────

    private fun detectOnsets(t: Long, s0: Float, s1: Float, s2: Float, s3: Float) {
        val sig = floatArrayOf(s0, s1, s2, s3)
        for (i in 0 until 4) {
            z2[i] = z1[i]
            z1[i] = z0[i]
            z0[i] = sig[i] / (avg[i] + 2f * dev[i] + 1e-3f)
            avg[i] = avg[i] * 0.98f + sig[i] * 0.02f
            dev[i] = dev[i] * 0.98f + abs(sig[i] - avg[i]) * 0.02f
        }
        val tc = t1
        t1 = t
        if (tc == 0L) return
        for (i in 0 until 4) {
            val z = z1[i]
            if (!(z > 1f && z > z2[i] && z >= z0[i])) continue
            if (tc - lastOnset[i] < refrNs[i]) continue
            // 다른 악기가 훨씬 세게 반응한 프레임이면 그 악기 소리로 본다
            if (i == Beat.SNARE && z < 0.5f * nb(Beat.KICK)) continue
            if (i == Beat.MELODY &&
                (z < 0.3f * nb(Beat.KICK) || z < 0.6f * nb(Beat.HAT) || z < 0.6f * nb(Beat.SNARE))
            ) continue
            lastOnset[i] = tc
            Beat.live[i] = 1f
            if (Beat.locked) {
                val s = Math.round(Beat.grid.stepAt(tc))
                hitRing[i][hitPos[i]] = s
                hitPos[i] = (hitPos[i] + 1) % hitRing[i].size
            }
        }
    }

    private fun nb(i: Int) = max(z0[i], max(z1[i], z2[i]))

    /** 120ms 이상 지난 16분음표 칸을 확정하며 패턴 기억을 갱신 */
    private fun learnPattern(t: Long) {
        val g = Beat.grid
        val cur = floor(g.stepAt(t - 120_000_000L)).toLong()
        if (seenEpoch != Beat.epoch || lastFinal == Long.MIN_VALUE || cur - lastFinal > 64) {
            seenEpoch = Beat.epoch
            lastFinal = cur
            for (r in hitRing) r.fill(Long.MIN_VALUE)
            return
        }
        var s = lastFinal + 1
        while (s <= cur && s <= lastFinal + 8) {
            val i16 = Math.floorMod(s, 16L).toInt()
            val i64 = Math.floorMod(s, 64L).toInt()
            for (i in 0 until 4) {
                var hit = 0f
                for (h in hitRing[i]) if (h == s) {
                    hit = 1f
                    break
                }
                Pattern.m16[i][i16] = Pattern.m16[i][i16] * 0.7f + hit * 0.3f
                Pattern.m64[i][i64] = Pattern.m64[i][i64] * 0.5f + hit * 0.5f
            }
            Pattern.learned++
            s++
        }
        lastFinal = s - 1
    }

    // ───────── 템포 / 박자 ─────────

    private fun estimate() {
        val len = min(envCount, envLen)
        val o = FloatArray(len)
        val ol = FloatArray(len)
        val ts = LongArray(len)
        for (i in 0 until len) {
            val idx = ((envPos - len + i) % envLen + envLen) % envLen
            o[i] = env[idx]
            ol[i] = envLow[idx]
            ts[i] = envT[idx]
        }
        val d = detrend(o)
        val dl = detrend(ol)

        // 템포: 자기상관 (65~190 BPM, 120 근처 선호)
        val lagMin = floor(fps * 60 / 190).toInt()
        val lagMax = ceil(fps * 60 / 65).toInt()
        val acMax = min(2 * lagMax + 1, len - 1)
        val ac = FloatArray(acMax + 1)
        for (lag in lagMin..acMax) {
            var s = 0f
            for (i in lag until len) s += d[i] * d[i - lag]
            ac[lag] = s / (len - lag)
        }
        val score = FloatArray(lagMax + 2)
        var best = lagMin
        var bestS = -1f
        var sum = 0f
        for (lag in lagMin..lagMax) {
            val bpm = fps * 60 / lag
            val wgt = exp(-0.5 * (log2(bpm / 120.0) / 0.8).pow(2)).toFloat()
            val dbl = if (2 * lag <= acMax) ac[2 * lag] else 0f
            val s = (ac[lag] + 0.5f * dbl) * wgt
            score[lag] = s
            sum += s
            if (s > bestS) {
                bestS = s
                best = lag
            }
        }
        val mean = sum / (lagMax - lagMin + 1)
        val conf = if (mean > 1e-9f) bestS / mean else 0f
        var lagF = best.toDouble()
        if (best > lagMin && best < lagMax) {
            val a = score[best - 1]
            val b = score[best]
            val c = score[best + 1]
            val den = a - 2 * b + c
            if (abs(den) > 1e-9f) lagF += (0.5 * (a - c) / den).coerceIn(-0.5, 0.5)
        }

        // 위상: 하이햇은 엇박에 많아서 저음 온셋을 섞어야 정박에 맞는다
        val mFull = d.average().toFloat() + 1e-9f
        val mLow = dl.average().toFloat() + 1e-9f
        val ph = FloatArray(len) { d[it] / mFull + 1.5f * dl[it] / mLow }
        val phases = ceil(lagF).toInt()
        var bestPh = 0
        var bestV = -1f
        for (p in 0 until phases) {
            var v = 0f
            var wt = 1f
            var k = 0
            while (true) {
                val idx = len - 1 - (p + k * lagF).roundToInt()
                if (idx < 1) break
                val right = if (idx + 1 < len) ph[idx + 1] else 0f
                v += wt * (ph[idx] + 0.5f * (ph[idx - 1] + right))
                wt *= 0.9f
                k++
            }
            if (v > bestV) {
                bestV = v
                bestPh = p
            }
        }
        val beatT = ts[len - 1 - bestPh]
        update(lagF / fps * 1e9, beatT, conf)
    }

    private fun detrend(o: FloatArray): FloatArray {
        val len = o.size
        val pre = FloatArray(len + 1)
        for (i in 0 until len) pre[i + 1] = pre[i] + o[i]
        return FloatArray(len) {
            val a = max(0, it - 8)
            val b = min(len, it + 9)
            max(0f, o[it] - (pre[b] - pre[a]) / (b - a))
        }
    }

    private fun relock(periodNs: Long, beatT: Long) {
        Beat.grid = Grid(beatT, periodNs, 0L)
        Beat.epoch++
        Pattern.reset()
    }

    private fun update(newNs: Double, beatT: Long, conf: Float) {
        Beat.confidence = conf
        if (!Beat.locked) {
            if (candNs > 0 && abs(newNs / candNs - 1) < 0.04) agree++ else agree = 0
            candNs = newNs
            if (agree >= 2 && conf > 1.3f) {
                relock(newNs.toLong(), beatT)
                Beat.locked = true
                mismatch = 0
                weak = 0
            }
            return
        }
        val g = Beat.grid
        val cur = g.periodNs.toDouble()
        val r = newNs / cur
        when {
            abs(r - 1) < 0.05 -> {
                mismatch = 0
                nudge(beatT, (cur * 0.85 + newNs * 0.15).toLong())
            }
            abs(r - 2) < 0.1 -> {          // 반박자로 들린 경우: 템포 유지, 위상만 보정
                mismatch = 0
                nudge(beatT, g.periodNs)
            }
            abs(r - 0.5) < 0.05 -> mismatch = 0
            else -> if (++mismatch >= 5) {  // 곡이 바뀜 → 새 템포로 다시 잡기
                relock(newNs.toLong(), beatT)
                mismatch = 0
            }
        }
        weak = if (conf < 1.15f) weak + 1 else 0
        if (weak > 10) {
            Beat.locked = false
            agree = 0
        }
    }

    /** 예측 박자 시계를 측정값 쪽으로 조금 당긴다. 박자 번호(anchorIdx)는 이어진다. */
    private fun nudge(beatT: Long, newPeriod: Long) {
        val g = Beat.grid
        val k = Math.round((beatT - g.anchorNs).toDouble() / g.periodNs)
        val pred = g.anchorNs + k * g.periodNs
        val err = beatT - pred
        Beat.grid = Grid(pred + (err * 0.25).toLong(), newPeriod, g.anchorIdx + k)
    }

    private fun fft() {
        var size = 2
        while (size <= n) {
            val h = size / 2
            val step = n / size
            var i = 0
            while (i < n) {
                for (j in 0 until h) {
                    val c = cosT[j * step]
                    val s = sinT[j * step]
                    val a = i + j
                    val b = a + h
                    val tr = re[b] * c - im[b] * s
                    val ti = re[b] * s + im[b] * c
                    re[b] = re[a] - tr
                    im[b] = im[a] - ti
                    re[a] += tr
                    im[a] += ti
                }
                i += size
            }
            size *= 2
        }
    }
}
