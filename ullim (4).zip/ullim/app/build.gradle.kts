plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ullim.rhythm"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ullim.rhythm"
        minSdk = 29          // 다른 앱 소리 캡처는 Android 10 이상에서만 가능
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }

    // 개인용 서명 키(저장소에 포함). 매번 같은 키로 서명해야 새 버전을 덮어 설치할 수 있다.
    signingConfigs {
        create("ullim") {
            storeFile = file("ullim.jks")
            storePassword = "ullim123"
            keyAlias = "ullim"
            keyPassword = "ullim123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("ullim")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("ullim")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
