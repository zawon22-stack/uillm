package com.ullim.rhythm

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * 울림 — 다이얼 리듬 게임.
 *
 * 화면 가운데 '코어'가 음악 박자에 맞춰 뛰고, 바깥에서 파동이 박자에 맞춰 조여 온다.
 * - 벽 고리(색): 빈틈이 있다. 손가락을 원 모양으로 돌려 내 빛을 빈틈에 두면 통과.
 * - 빛 구슬: 궤도에 닿을 때 그 자리에 있으면 수집.
 * - 흰 고리(공명): 곡이 고조될 때 온다. 궤도에 겹치는 순간 아무 곳이나 탭.
 * 실수하면 '하모니'가 줄고, 0이 되면 끝.
 */
@SuppressLint("ViewConstructor")
class GameView(ctx: Context, private val host: Host) :
    SurfaceView(ctx), SurfaceHolder.Callback, Runnable {

    interface Host {
        fun requestCapture()
    }

    private enum class St { IDLE, LISTEN, PLAY, OVER }

    private class Wave(val type: Int, val t: Long, val ang: Float, val half: Float) {
        var judged = false
        var ok = false
    }

    private class Spark(
        var x: Float, var y: Float, val vx: Float, val vy: Float, var life: Float, val color: Int
    )

    private class Pop(val text: String, val x: Float, var y: Float, var life: Float, val color: Int)

    companion object {
        const val GATE = 0
        const val ORB = 1
        const val PULSE = 2
        const val TRAVEL = 1_500_000_000L     // 파동이 화면 끝에서 궤도까지 오는 시간
        const val PERFECT = 70_000_000L
        const val GOOD = 140_000_000L
        val TAU = (2 * PI).toFloat()
        val PIF = PI.toFloat()
    }

    private val lock = Any()
    @Volatile private var running = false
    private var thread: Thread? = null
    private val dp = resources.displayMetrics.density
    private val prefs = ctx.getSharedPreferences("ullim", Context.MODE_PRIVATE)
    private val rnd = Random(System.nanoTime())

    @Volatile var message: String? = null

    private var st = St.IDLE
    private var w = 1f
    private var h = 1f
    private var cx = 0f
    private var cy = 0f
    private var orbitR = 1f
    private var coreR = 1f
    private var outR = 1f

    private var theta = -PIF / 2
    private val trail = FloatArray(14) { -PIF / 2 }
    private var trailPos = 0
    private val waves = ArrayList<Wave>()
    private val sparks = ArrayList<Spark>()
    private val pops = ArrayList<Pop>()

    private var score = 0L
    private var combo = 0
    private var maxCombo = 0
    private var harmony = 100f
    private var best = prefs.getLong("best", 0L)
    private var offsetMs = prefs.getInt("offset", 0)
    private var lastSched = 0L
    private var beatIdx = 0
    private var lastGap = -PIF / 2
    private var lastPulse = -10
    private var playStart = 0L
    private var overAt = 0L

    private var shake = 0f
    private var flash = 0f
    private var hue = 205f
    private var dialId = -1
    private var dialAng = 0f

    private val startBtn = RectF()
    private val minusBtn = RectF()
    private val plusBtn = RectF()
    private val oval = RectF()
    private val hsvTmp = FloatArray(3)

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        color = Color.WHITE
    }
    private val vig = Paint()

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    // ───────────────────────── 생명주기 / 루프 ─────────────────────────

    override fun surfaceCreated(hd: SurfaceHolder) {
        running = true
        thread = Thread(this, "game").also { it.start() }
    }

    override fun surfaceChanged(hd: SurfaceHolder, format: Int, width: Int, height: Int) {
        synchronized(lock) { layout(width.toFloat(), height.toFloat()) }
    }

    override fun surfaceDestroyed(hd: SurfaceHolder) {
        running = false
        try {
            thread?.join(500)
        } catch (_: InterruptedException) {
        }
        thread = null
    }

    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            val dt = min(0.05f, (now - last) / 1e9f)
            last = now
            val c: Canvas? = try {
                holder.lockHardwareCanvas()
            } catch (e: Exception) {
                null
            }
            if (c == null) {
                Thread.sleep(16)
                continue
            }
            try {
                synchronized(lock) {
                    update(now, dt)
                    render(c, now)
                }
            } finally {
                holder.unlockCanvasAndPost(c)
            }
        }
    }

    private fun layout(W: Float, H: Float) {
        w = W
        h = H
        cx = W / 2
        cy = H * 0.5f
        val m = min(W, H)
        orbitR = m * 0.36f
        coreR = m * 0.075f
        outR = hypot(W, H) / 2 + 30 * dp
        vig.shader = RadialGradient(
            cx, cy, hypot(W, H) / 2,
            intArrayOf(0x00000000, 0x00000000, 0xC8000000.toInt()),
            floatArrayOf(0f, 0.42f, 1f), Shader.TileMode.CLAMP
        )
        val bw = min(W * 0.62f, 260 * dp)
        val bh = 56 * dp
        val by = min(cy + orbitR + 70 * dp, H - bh - 110 * dp)
        startBtn.set(cx - bw / 2, by, cx + bw / 2, by + bh)
        val sy = H - 76 * dp
        minusBtn.set(14 * dp, sy, 14 * dp + 56 * dp, sy + 48 * dp)
        plusBtn.set(W - 14 * dp - 56 * dp, sy, W - 14 * dp, sy + 48 * dp)
    }

    // ───────────────────────── 게임 로직 ─────────────────────────

    private fun update(now: Long, dt: Float) {
        val cap = Beat.capturing
        if (!cap && (st == St.LISTEN || st == St.PLAY)) st = St.IDLE
        if (cap && st == St.IDLE) st = St.LISTEN
        if (st == St.LISTEN && Beat.locked) startPlay(now)
        if (st == St.PLAY) {
            if (Beat.locked) schedule(now)
            judge(now)
            if (harmony <= 0f) gameOver(now)
        }
        waves.removeAll { it.judged && now - it.t > TRAVEL * 6 / 10 }

        val it1 = sparks.iterator()
        while (it1.hasNext()) {
            val s = it1.next()
            s.x += s.vx * dt
            s.y += s.vy * dt
            s.life -= dt * 1.6f
            if (s.life <= 0f) it1.remove()
        }
        val it2 = pops.iterator()
        while (it2.hasNext()) {
            val p = it2.next()
            p.y -= 40 * dp * dt
            p.life -= dt * 1.1f
            if (p.life <= 0f) it2.remove()
        }
        shake *= exp(-dt * 10f)
        flash *= exp(-dt * 6f)
        hue = (hue + dt * (3f + min(combo, 60) * 0.25f)) % 360f
        trail[trailPos] = theta
        trailPos = (trailPos + 1) % trail.size
    }

    private fun startPlay(now: Long) {
        waves.clear()
        score = 0
        combo = 0
        maxCombo = 0
        harmony = 100f
        beatIdx = 0
        lastPulse = -10
        lastSched = now + TRAVEL * 6 / 10
        playStart = now
        st = St.PLAY
    }

    private fun gameOver(now: Long) {
        st = St.OVER
        overAt = now
        if (score > best) {
            best = score
            prefs.edit().putLong("best", best).apply()
        }
    }

    /** 앞으로 TRAVEL 안에 올 박자마다 파동을 만든다 */
    private fun schedule(now: Long) {
        val off = offsetMs * 1_000_000L
        val p = Beat.periodNs
        var from = max(lastSched + p * 6 / 10, now + TRAVEL * 6 / 10)
        while (true) {
            val b = Beat.beatAtOrAfter(from - off) + off
            if (b > now + TRAVEL) break
            pattern(b, p)
            lastSched = b
            from = b + p * 6 / 10
        }
    }

    /** 지금 음악의 성격(에너지, 저음, 고음)으로 패턴을 고른다 */
    private fun pattern(b: Long, p: Long) {
        beatIdx++
        if (p < 360_000_000L && beatIdx % 2 == 1) return // 아주 빠른 곡은 두 박에 하나
        val diff = min(1f, combo / 60f)
        val energy = Beat.level / (Beat.levelAvg + 1e-6f)
        val bassUp = Beat.bass / (Beat.bassAvg + 1e-6f)
        val highUp = Beat.high / (Beat.highAvg + 1e-6f)

        if (energy > 1.2f && beatIdx - lastPulse >= 4 && beatIdx % 2 == 0) {
            waves.add(Wave(PULSE, b, 0f, 0f))
            lastPulse = beatIdx
            return
        }
        val ps = p / 1e9f
        if (beatIdx % 2 == 0 || bassUp > 1.08f) {
            val step = min(2.4f, ps * 5f)
            lastGap = wrap(lastGap + (rnd.nextFloat() * 2f - 1f) * step)
            waves.add(Wave(GATE, b, lastGap, 0.85f - 0.3f * diff))
        } else {
            waves.add(Wave(ORB, b, wrap(lastGap + (rnd.nextFloat() * 2f - 1f) * 0.8f), 0f))
        }
        if (highUp > 1.04f && p > 380_000_000L) {
            waves.add(Wave(ORB, b + p / 2, wrap(lastGap + (rnd.nextFloat() * 2f - 1f) * 0.6f), 0f))
        }
    }

    private fun judge(now: Long) {
        for (wv in waves) {
            if (wv.judged) continue
            when (wv.type) {
                GATE -> if (now >= wv.t) {
                    wv.judged = true
                    if (abs(wrap(theta - wv.ang)) <= wv.half) {
                        wv.ok = true
                        reward(100, hsv(hue + 150f, 0.6f, 1f))
                    } else crash()
                }
                ORB -> if (now >= wv.t) {
                    wv.judged = true
                    if (abs(wrap(theta - wv.ang)) <= 0.38f) {
                        wv.ok = true
                        reward(60, hsv(hue + 60f, 0.4f, 1f))
                    } else {
                        combo = 0
                        harmony -= 3f
                    }
                }
                PULSE -> if (now > wv.t + GOOD) {
                    wv.judged = true
                    combo = 0
                    harmony -= 10f
                    pop("놓침", Color.rgb(255, 120, 140))
                }
            }
        }
    }

    private fun reward(base: Int, color: Int) {
        combo++
        maxCombo = max(maxCombo, combo)
        score += base.toLong() * (1 + combo / 20)
        harmony = min(100f, harmony + 1.5f)
        burst(px(), py(), color, 10)
        if (combo % 25 == 0) pop("콤보 $combo", Color.WHITE)
    }

    private fun crash() {
        combo = 0
        harmony -= 14f
        shake = 16 * dp
        flash = 1f
        burst(px(), py(), Color.rgb(255, 70, 90), 16)
        pop("충돌", Color.rgb(255, 110, 130))
        post { performHapticFeedback(HapticFeedbackConstants.LONG_PRESS) }
    }

    /** 공명(흰 고리) 판정: 탭한 시각과 고리가 궤도에 닿는 시각의 차이 */
    private fun tap(t: Long) {
        var target: Wave? = null
        var bestD = Long.MAX_VALUE
        for (wv in waves) {
            if (wv.type != PULSE || wv.judged) continue
            val d = abs(t - wv.t)
            if (d < bestD) {
                bestD = d
                target = wv
            }
        }
        val wv = target ?: return
        if (bestD > GOOD) return
        wv.judged = true
        wv.ok = true
        if (bestD <= PERFECT) {
            reward(300, Color.WHITE)
            pop("완벽", Color.WHITE)
        } else {
            reward(150, Color.WHITE)
            pop("좋아", Color.rgb(220, 230, 255))
        }
        for (i in 0 until 28) {
            val a = i * TAU / 28
            sparks.add(
                Spark(
                    cx + orbitR * cos(a), cy + orbitR * sin(a),
                    cos(a) * 160 * dp, sin(a) * 160 * dp, 1f, Color.WHITE
                )
            )
        }
        performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    // ───────────────────────── 입력 ─────────────────────────

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val tNs = System.nanoTime() - (SystemClock.uptimeMillis() - e.eventTime) * 1_000_000L
        synchronized(lock) {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    val i = e.actionIndex
                    val x = e.getX(i)
                    val y = e.getY(i)
                    if (down(x, y, tNs) && dialId == -1) {
                        dialId = e.getPointerId(i)
                        dialAng = atan2(y - cy, x - cx)
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    val i = e.findPointerIndex(dialId)
                    if (i >= 0) {
                        val x = e.getX(i)
                        val y = e.getY(i)
                        val a = atan2(y - cy, x - cx)
                        if (hypot(x - cx, y - cy) > coreR * 0.6f) theta = wrap(theta + wrap(a - dialAng))
                        dialAng = a
                    }
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    if (e.getPointerId(e.actionIndex) == dialId) {
                        val ni = if (e.actionIndex == 0) 1 else 0
                        dialId = e.getPointerId(ni)
                        dialAng = atan2(e.getY(ni) - cy, e.getX(ni) - cx)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dialId = -1
            }
        }
        return true
    }

    /** 손가락이 닿음. 다이얼로 써도 되는 터치면 true */
    private fun down(x: Float, y: Float, t: Long): Boolean {
        when (st) {
            St.IDLE -> {
                if (startBtn.contains(x, y)) host.requestCapture()
                return true
            }
            St.OVER -> {
                if (t - overAt > 900_000_000L) {
                    if (Beat.locked) startPlay(System.nanoTime()) else st = St.LISTEN
                }
                return false
            }
            else -> {}
        }
        if (minusBtn.contains(x, y)) {
            setOffset(offsetMs - 10)
            return false
        }
        if (plusBtn.contains(x, y)) {
            setOffset(offsetMs + 10)
            return false
        }
        if (st == St.PLAY) tap(t)
        return true
    }

    private fun setOffset(v: Int) {
        offsetMs = v.coerceIn(-400, 400)
        prefs.edit().putInt("offset", offsetMs).apply()
    }

    // ───────────────────────── 그리기 ─────────────────────────

    private fun render(c: Canvas, now: Long) {
        val off = offsetMs * 1_000_000L
        var pulse = 0f
        if (Beat.locked) {
            val p = Beat.periodNs
            val lb = Beat.beatAtOrAfter(now - off - p + 1) + off
            pulse = exp(-(now - lb) / 1.2e8).toFloat()
        }

        c.drawColor(hsv(hue, 0.62f, 0.11f + 0.05f * pulse))
        c.drawRect(0f, 0f, w, h, vig)
        if (flash > 0.02f) {
            fill.color = Color.argb((flash * 90).toInt(), 255, 40, 70)
            c.drawRect(0f, 0f, w, h, fill)
        }

        c.save()
        if (shake > 0.5f) c.translate((rnd.nextFloat() - 0.5f) * shake, (rnd.nextFloat() - 0.5f) * shake)
        drawSpectrum(c)
        stroke.strokeWidth = 2 * dp
        stroke.color = Color.argb(46 + (40 * pulse).toInt(), 255, 255, 255)
        c.drawCircle(cx, cy, orbitR, stroke)
        drawWaves(c, now)
        drawCore(c, pulse)
        if (st != St.IDLE) drawPlayer(c)
        drawSparks(c)
        c.restore()

        drawHud(c, now)
    }

    private fun drawSpectrum(c: Canvas) {
        val n = Beat.BANDS
        val base = coreR * 1.55f
        val len = orbitR * 0.5f
        stroke.strokeWidth = max(2f, (PIF * base / n) * 0.55f)
        for (i in 0 until n) {
            val v = Beat.spec[i]
            stroke.color = hsv(hue + i * 4f, 0.5f, 1f, (50 + 150 * v).toInt())
            val a = (i + 0.5f) / n * PIF
            for (side in 0..1) {
                val ang = -PIF / 2 + if (side == 0) a else -a
                val ca = cos(ang)
                val sa = sin(ang)
                val r2 = base + 3 * dp + v * len
                c.drawLine(cx + ca * base, cy + sa * base, cx + ca * r2, cy + sa * r2, stroke)
            }
        }
    }

    private fun drawCore(c: Canvas, pulse: Float) {
        val r = coreR * (1f + 0.25f * pulse)
        fill.color = hsv(hue + 25f, 0.5f, 1f, (30 + 90 * pulse).toInt())
        c.drawCircle(cx, cy, r * 1.7f, fill)
        fill.color = hsv(hue + 25f, 0.18f, 1f)
        c.drawCircle(cx, cy, r, fill)
        fill.color = hsv(hue, 0.7f, 0.4f)
        c.drawCircle(cx, cy, r * 0.42f, fill)
    }

    private fun drawWaves(c: Canvas, now: Long) {
        val span = outR - orbitR
        val inner = coreR * 1.3f
        for (wv in waves) {
            val r = orbitR + span * ((wv.t - now).toFloat() / TRAVEL)
            if (r > outR || r < inner) continue
            val a = if (r >= orbitR) 0.35f + 0.65f * (1f - (r - orbitR) / span)
            else ((r - inner) / (orbitR - inner)).coerceIn(0f, 1f) * (if (wv.ok) 0.25f else 0.6f)
            val al = (a * 255).toInt().coerceIn(0, 255)
            oval.set(cx - r, cy - r, cx + r, cy + r)
            when (wv.type) {
                GATE -> {
                    stroke.strokeWidth = 9 * dp
                    stroke.color = hsv(hue + 150f, 0.62f, 1f, al)
                    val start = Math.toDegrees((wv.ang + wv.half).toDouble()).toFloat()
                    val sweep = 360f - Math.toDegrees((2 * wv.half).toDouble()).toFloat()
                    c.drawArc(oval, start, sweep, false, stroke)
                }
                ORB -> {
                    val x = cx + r * cos(wv.ang)
                    val y = cy + r * sin(wv.ang)
                    fill.color = hsv(hue + 60f, 0.5f, 1f, al / 3)
                    c.drawCircle(x, y, 17 * dp, fill)
                    fill.color = hsv(hue + 60f, 0.28f, 1f, al)
                    c.drawCircle(x, y, 7 * dp, fill)
                }
                PULSE -> {
                    stroke.strokeWidth = 5 * dp
                    stroke.color = Color.argb(al, 255, 255, 255)
                    c.drawCircle(cx, cy, r, stroke)
                    if (!wv.judged && r > orbitR) {
                        stroke.strokeWidth = 2 * dp
                        stroke.color = Color.argb(al / 2, 255, 255, 255)
                        c.drawCircle(cx, cy, orbitR + 6 * dp, stroke)
                    }
                }
            }
        }
    }

    private fun drawPlayer(c: Canvas) {
        for (k in trail.indices) {
            val ang = trail[(trailPos + k) % trail.size]
            val f = k.toFloat() / trail.size
            fill.color = hsv(hue + 60f, 0.3f, 1f, (f * 90).toInt())
            c.drawCircle(cx + orbitR * cos(ang), cy + orbitR * sin(ang), (4 + 6 * f) * dp, fill)
        }
        fill.color = Color.argb(70, 255, 255, 255)
        c.drawCircle(px(), py(), 21 * dp, fill)
        fill.color = Color.WHITE
        c.drawCircle(px(), py(), 11 * dp, fill)
    }

    private fun drawSparks(c: Canvas) {
        for (s in sparks) {
            fill.color = s.color
            fill.alpha = (s.life.coerceIn(0f, 1f) * 255).toInt()
            c.drawCircle(s.x, s.y, 3 * dp, fill)
        }
        text.textAlign = Paint.Align.CENTER
        text.textSize = 20 * dp
        for (p in pops) {
            text.color = p.color
            text.alpha = (p.life.coerceIn(0f, 1f) * 255).toInt()
            c.drawText(p.text, p.x, p.y, text)
        }
        text.alpha = 255
    }

    private fun drawHud(c: Canvas, now: Long) {
        val top = 40 * dp
        val pad = 20 * dp
        text.color = Color.WHITE

        // 오른쪽 위: 상태 / BPM
        text.textAlign = Paint.Align.RIGHT
        text.textSize = 15 * dp
        val status = when {
            !Beat.capturing -> ""
            Beat.silent -> "소리 없음"
            Beat.locked -> (if (Beat.source == 2) "♪ ${Beat.bpm()} BPM · 예비 입력" else "♪ ${Beat.bpm()} BPM")
            else -> "박자 찾는 중"
        }
        text.alpha = 210
        c.drawText(status, w - pad, top + 16 * dp, text)
        text.alpha = 255

        if (st == St.PLAY || st == St.OVER) {
            text.textAlign = Paint.Align.LEFT
            text.textSize = 32 * dp
            c.drawText(String.format("%,d", score), pad, top + 26 * dp, text)
            text.textSize = 15 * dp
            text.alpha = 200
            if (combo > 1) c.drawText("콤보 $combo", pad, top + 50 * dp, text)
            text.alpha = 255

            // 하모니 게이지
            val bw = min(w * 0.36f, 160 * dp)
            val bx = w - pad - bw
            val by = top + 28 * dp
            fill.color = Color.argb(50, 255, 255, 255)
            c.drawRoundRect(bx, by, bx + bw, by + 7 * dp, 4 * dp, 4 * dp, fill)
            fill.color = if (harmony > 35f) hsv(hue + 150f, 0.55f, 1f) else Color.rgb(255, 90, 110)
            val f = (harmony / 100f).coerceIn(0f, 1f)
            c.drawRoundRect(bx, by, bx + bw * f, by + 7 * dp, 4 * dp, 4 * dp, fill)
            text.textSize = 12 * dp
            text.textAlign = Paint.Align.RIGHT
            text.alpha = 170
            c.drawText("하모니", w - pad, by + 24 * dp, text)
            text.alpha = 255
        }

        text.textAlign = Paint.Align.CENTER
        val below = cy + orbitR + 56 * dp
        when (st) {
            St.IDLE -> drawIdle(c)
            St.LISTEN -> {
                val err = Beat.error
                if (Beat.silent) {
                    line(c, "음악을 틀어 주세요", below, 20f, 255)
                    line(c, "다른 앱에서 재생 중인 소리를 그대로 들어요", below + 28 * dp, 13f, 170)
                    line(c, "스포티파이 등도 예비 입력으로 들어요", below + 48 * dp, 13f, 130)
                } else {
                    line(c, "박자를 듣는 중…", below, 20f, 255)
                    val dots = ((now / 300_000_000L) % 4).toInt()
                    line(c, "●".repeat(dots + 1), below + 30 * dp, 12f, 170)
                }
                if (err != null) line(c, err, below + 72 * dp, 13f, 220)
            }
            St.PLAY -> {
                if (now - playStart < 6_000_000_000L) {
                    line(c, "손가락을 원 모양으로 돌려 빈틈으로", below, 15f, 220)
                    line(c, "흰 고리가 궤도에 겹칠 때는 탭!", below + 24 * dp, 15f, 220)
                } else if (!Beat.locked) {
                    line(c, "박자를 다시 찾는 중…", below, 15f, 200)
                }
            }
            St.OVER -> {
                fill.color = Color.argb(170, 0, 0, 0)
                c.drawRect(0f, 0f, w, h, fill)
                line(c, "하모니가 끊겼어요", h * 0.36f, 24f, 255)
                line(c, String.format("%,d", score), h * 0.36f + 64 * dp, 48f, 255)
                line(c, "최고 ${String.format("%,d", best)}  ·  최대 콤보 $maxCombo", h * 0.36f + 100 * dp, 15f, 200)
                if (now - overAt > 900_000_000L) line(c, "탭해서 다시 시작", h * 0.36f + 160 * dp, 17f, 230)
            }
        }

        if (st == St.LISTEN || st == St.PLAY) drawSync(c)
    }

    private fun drawIdle(c: Canvas) {
        val titleY = max(110 * dp, cy - orbitR - 70 * dp)
        line(c, "울림", titleY, 52f, 255)
        line(c, "지금 듣는 음악으로 하는 리듬 게임", titleY + 36 * dp, 15f, 200)

        fill.color = hsv(hue + 150f, 0.55f, 1f)
        c.drawRoundRect(startBtn, 28 * dp, 28 * dp, fill)
        text.color = hsv(hue, 0.7f, 0.18f)
        text.textSize = 19 * dp
        c.drawText("시작하기", startBtn.centerX(), startBtn.centerY() + 7 * dp, text)
        text.color = Color.WHITE

        val y = startBtn.bottom + 30 * dp
        line(c, "공유 창이 뜨면 '전체 화면'으로 시작하세요", y, 13f, 170)
        line(c, "소리는 박자 분석에만 쓰고 저장하지 않아요", y + 20 * dp, 13f, 130)
        val msg = message ?: Beat.error
        if (msg != null) {
            text.color = Color.rgb(255, 150, 165)
            line(c, msg, startBtn.top - 18 * dp, 14f, 255)
            text.color = Color.WHITE
        }
    }

    private fun drawSync(c: Canvas) {
        fill.color = Color.argb(40, 255, 255, 255)
        c.drawRoundRect(minusBtn, 14 * dp, 14 * dp, fill)
        c.drawRoundRect(plusBtn, 14 * dp, 14 * dp, fill)
        text.textAlign = Paint.Align.CENTER
        text.textSize = 24 * dp
        text.alpha = 230
        c.drawText("−", minusBtn.centerX(), minusBtn.centerY() + 8 * dp, text)
        c.drawText("+", plusBtn.centerX(), plusBtn.centerY() + 8 * dp, text)
        val sign = if (offsetMs > 0) "+" else ""
        line(c, "싱크 $sign${offsetMs}ms", minusBtn.centerY() - 2 * dp, 15f, 220)
        line(c, "코어가 들리는 박자에 뛰도록", minusBtn.centerY() + 17 * dp, 11.5f, 140)
    }

    private fun line(c: Canvas, s: String, y: Float, sizeDp: Float, alpha: Int) {
        text.textAlign = Paint.Align.CENTER
        text.textSize = sizeDp * dp
        text.alpha = alpha
        c.drawText(s, cx, y, text)
        text.alpha = 255
    }

    // ───────────────────────── 도우미 ─────────────────────────

    private fun px() = cx + orbitR * cos(theta)
    private fun py() = cy + orbitR * sin(theta)

    private fun burst(x: Float, y: Float, color: Int, count: Int) {
        repeat(count) {
            val a = rnd.nextFloat() * TAU
            val sp = (60 + rnd.nextFloat() * 160) * dp
            sparks.add(Spark(x, y, cos(a) * sp, sin(a) * sp, 0.6f + rnd.nextFloat() * 0.4f, color))
        }
    }

    private fun pop(s: String, color: Int) {
        pops.add(Pop(s, px(), py() - 30 * dp, 1f, color))
    }

    private fun wrap(a: Float): Float {
        var x = (a + PIF) % TAU
        if (x < 0) x += TAU
        return x - PIF
    }

    private fun hsv(hh: Float, s: Float, v: Float, a: Int = 255): Int {
        hsvTmp[0] = ((hh % 360f) + 360f) % 360f
        hsvTmp[1] = s
        hsvTmp[2] = v
        return Color.HSVToColor(a.coerceIn(0, 255), hsvTmp)
    }
}
