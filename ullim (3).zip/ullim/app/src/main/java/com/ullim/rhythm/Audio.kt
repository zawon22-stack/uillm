package com.ullim.rhythm

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * 오디오 스레드(분석)와 게임 스레드(화면)가 함께 보는 공유 상태.
 * 모든 시간은 System.nanoTime() 기준.
 */
object Beat {
    const val BANDS = 40

    @Volatile var capturing = false
    @Volatile var error: String? = null
    @Volatile var locked = false
    @Volatile var silent = true
    @Volatile var periodNs = 500_000_000L
    @Volatile var anchorNs = 0L
    @Volatile var confidence = 0f

    @Volatile var level = 0f
    @Volatile var levelAvg = 0.02f
    @Volatile var bass = 0f
    @Volatile var high = 0f
    @Volatile var bassAvg = 1f
    @Volatile var highAvg = 1f

    /** 0..1 로 정규화된 스펙트럼 (시각 효과용) */
    val spec = FloatArray(BANDS)

    fun bpm(): Int = (60e9 / periodNs).roundToInt()

    /** t 이후(포함) 첫 예측 박자 시각 */
    fun beatAtOrAfter(t: Long): Long {
        val p = periodNs
        val a = anchorNs
        val k = ceil((t - a).toDouble() / p).toLong()
        return a + k * p
    }
}

/**
 * 실시간 비트 트래커.
 * 1) FFT로 스펙트럴 플럭스(소리가 '새로 터지는' 정도)를 구해 온셋 곡선을 만들고
 * 2) 최근 ~7초 곡선의 자기상관으로 템포(BPM)를,
 * 3) 콤 필터로 박자 위상을 찾고
 * 4) 예측 박자 시계를 조금씩 보정한다(PLL처럼).
 */
class Analyzer(private val sr: Int) {
    private val n = 1024
    private val hop = 512
    private val fps = sr.toDouble() / hop

    private val ring = FloatArray(n)
    private var w = 0
    private var sinceHop = 0
    private val win = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / (n - 1))).toFloat() }
    private val re = FloatArray(n)
    private val im = FloatArray(n)
    private val cosT = FloatArray(n / 2) { cos(2.0 * PI * it / n).toFloat() }
    private val sinT = FloatArray(n / 2) { (-sin(2.0 * PI * it / n)).toFloat() }
    private val rev = IntArray(n)
    private val prev = FloatArray(n / 2)
    private val logMag = FloatArray(n / 2)

    private val bandLo = IntArray(Beat.BANDS)
    private val bandHi = IntArray(Beat.BANDS)
    private val bandTmp = FloatArray(Beat.BANDS)
    private var specPeak = 1f

    private val envLen = 600 // 약 7초
    private val env = FloatArray(envLen)
    private val envLow = FloatArray(envLen) // 저음(킥/베이스) 온셋: 박자 위상용
    private val envT = LongArray(envLen)
    private var envPos = 0
    private var envCount = 0
    private var frames = 0
    private var quiet = 0

    private var candNs = 0.0
    private var agree = 0
    private var mismatch = 0
    private var weak = 0
    private val halfWinNs = (n / 2 * 1e9 / sr).toLong()

    init {
        val bits = Integer.numberOfTrailingZeros(n)
        for (i in 0 until n) {
            var x = i
            var r = 0
            repeat(bits) {
                r = (r shl 1) or (x and 1)
                x = x shr 1
            }
            rev[i] = r
        }
        val binHz = sr.toDouble() / n
        for (b in 0 until Beat.BANDS) {
            val f0 = 40.0 * (12000.0 / 40.0).pow(b.toDouble() / Beat.BANDS)
            val f1 = 40.0 * (12000.0 / 40.0).pow((b + 1).toDouble() / Beat.BANDS)
            val lo = min(max(1, (f0 / binHz).toInt()), n / 2 - 2)
            bandLo[b] = lo
            bandHi[b] = max(lo + 1, min(n / 2, (f1 / binHz).toInt()))
        }
    }

    /** endNs = 이 버퍼의 마지막 샘플을 받은 시각 */
    fun feed(buf: ShortArray, count: Int, endNs: Long) {
        for (i in 0 until count) {
            ring[w] = buf[i] / 32768f
            w = (w + 1) % n
            if (++sinceHop >= hop) {
                sinceHop = 0
                val t = endNs - ((count - 1 - i) * 1e9 / sr).toLong() - halfWinNs
                frame(t)
            }
        }
    }

    private fun frame(t: Long) {
        var sq = 0f
        for (i in 0 until n) {
            val s = ring[(w + i) % n]
            sq += s * s
            val j = rev[i]
            re[j] = s * win[i]
            im[j] = 0f
        }
        fft()
        val rms = sqrt(sq / n)

        var flux = 0f
        var lowFlux = 0f
        var bass = 0f
        var high = 0f
        for (k in 1 until n / 2) {
            val mg = sqrt(re[k] * re[k] + im[k] * im[k])
            val lm = ln(1f + 50f * mg)
            val d = lm - prev[k]
            if (d > 0f) {
                flux += d
                if (k <= 10) lowFlux += d
            }
            prev[k] = lm
            logMag[k] = lm
            if (k <= 4) bass += lm else if (k in 47..232) high += lm
        }
        bass /= 4f
        high /= 186f

        // 시각화용 스펙트럼
        var peak = 0f
        for (b in 0 until Beat.BANDS) {
            var s = 0f
            for (k in bandLo[b] until bandHi[b]) s += logMag[k]
            s /= (bandHi[b] - bandLo[b])
            bandTmp[b] = s
            if (s > peak) peak = s
        }
        specPeak = max(peak, specPeak * 0.995f)
        for (b in 0 until Beat.BANDS) {
            val v = (bandTmp[b] / (specPeak + 1e-6f)).coerceIn(0f, 1f)
            val v2 = v * v
            Beat.spec[b] = if (v2 > Beat.spec[b]) v2 else Beat.spec[b] * 0.88f + v2 * 0.12f
        }

        Beat.level = Beat.level * 0.9f + rms * 0.1f
        Beat.levelAvg = Beat.levelAvg * 0.997f + rms * 0.003f
        Beat.bass = Beat.bass * 0.85f + bass * 0.15f
        Beat.high = Beat.high * 0.85f + high * 0.15f
        Beat.bassAvg = Beat.bassAvg * 0.997f + bass * 0.003f
        Beat.highAvg = Beat.highAvg * 0.997f + high * 0.003f

        // 무음 감지
        if (rms < 0.0015f) quiet++ else quiet = 0
        val nowSilent = quiet > fps * 1.2
        if (nowSilent && !Beat.silent) {
            Beat.locked = false
            agree = 0
            envCount = 0
        }
        Beat.silent = nowSilent
        if (nowSilent) return

        env[envPos] = flux
        envLow[envPos] = lowFlux
        envT[envPos] = t
        envPos = (envPos + 1) % envLen
        envCount++
        if (++frames % 15 == 0 && envCount >= fps * 3) estimate()
    }

    private fun estimate() {
        val len = min(envCount, envLen)
        val o = FloatArray(len)
        val ol = FloatArray(len)
        val ts = LongArray(len)
        for (i in 0 until len) {
            val idx = ((envPos - len + i) % envLen + envLen) % envLen
            o[i] = env[idx]
            ol[i] = envLow[idx]
            ts[i] = envT[idx]
        }
        val d = detrend(o)
        val dl = detrend(ol)

        // 템포: 자기상관 (65~190 BPM, 120 근처 선호)
        val lagMin = floor(fps * 60 / 190).toInt()
        val lagMax = ceil(fps * 60 / 65).toInt()
        val acMax = min(2 * lagMax + 1, len - 1)
        val ac = FloatArray(acMax + 1)
        for (lag in lagMin..acMax) {
            var s = 0f
            for (i in lag until len) s += d[i] * d[i - lag]
            ac[lag] = s / (len - lag)
        }
        val score = FloatArray(lagMax + 2)
        var best = lagMin
        var bestS = -1f
        var sum = 0f
        for (lag in lagMin..lagMax) {
            val bpm = fps * 60 / lag
            val wgt = exp(-0.5 * (log2(bpm / 120.0) / 0.8).pow(2)).toFloat()
            val dbl = if (2 * lag <= acMax) ac[2 * lag] else 0f
            val s = (ac[lag] + 0.5f * dbl) * wgt
            score[lag] = s
            sum += s
            if (s > bestS) {
                bestS = s
                best = lag
            }
        }
        val mean = sum / (lagMax - lagMin + 1)
        val conf = if (mean > 1e-9f) bestS / mean else 0f
        var lagF = best.toDouble()
        if (best > lagMin && best < lagMax) {
            val a = score[best - 1]
            val b = score[best]
            val c = score[best + 1]
            val den = a - 2 * b + c
            if (abs(den) > 1e-9f) lagF += (0.5 * (a - c) / den).coerceIn(-0.5, 0.5)
        }

        // 위상: 가장 최근 박자 위치 찾기 (콤 필터).
        // 하이햇은 엇박에 많아서 저음 온셋을 섞어야 정박에 맞는다.
        val mFull = d.average().toFloat() + 1e-9f
        val mLow = dl.average().toFloat() + 1e-9f
        val ph = FloatArray(len) { d[it] / mFull + 1.5f * dl[it] / mLow }
        val phases = ceil(lagF).toInt()
        var bestPh = 0
        var bestV = -1f
        for (p in 0 until phases) {
            var v = 0f
            var wt = 1f
            var k = 0
            while (true) {
                val idx = len - 1 - (p + k * lagF).roundToInt()
                if (idx < 1) break
                val right = if (idx + 1 < len) ph[idx + 1] else 0f
                v += wt * (ph[idx] + 0.5f * (ph[idx - 1] + right))
                wt *= 0.9f
                k++
            }
            if (v > bestV) {
                bestV = v
                bestPh = p
            }
        }
        val beatT = ts[len - 1 - bestPh]
        update(lagF / fps * 1e9, beatT, conf)
    }

    /** 지역 평균을 빼고 양수만 남긴 온셋 곡선 */
    private fun detrend(o: FloatArray): FloatArray {
        val len = o.size
        val pre = FloatArray(len + 1)
        for (i in 0 until len) pre[i + 1] = pre[i] + o[i]
        return FloatArray(len) {
            val a = max(0, it - 8)
            val b = min(len, it + 9)
            max(0f, o[it] - (pre[b] - pre[a]) / (b - a))
        }
    }

    private fun update(newNs: Double, beatT: Long, conf: Float) {
        Beat.confidence = conf
        if (!Beat.locked) {
            if (candNs > 0 && abs(newNs / candNs - 1) < 0.04) agree++ else agree = 0
            candNs = newNs
            if (agree >= 2 && conf > 1.3f) {
                Beat.periodNs = newNs.toLong()
                Beat.anchorNs = beatT
                Beat.locked = true
                mismatch = 0
                weak = 0
            }
            return
        }
        val cur = Beat.periodNs.toDouble()
        val r = newNs / cur
        when {
            abs(r - 1) < 0.05 -> {
                Beat.periodNs = (cur * 0.85 + newNs * 0.15).toLong()
                mismatch = 0
                nudge(beatT)
            }
            abs(r - 2) < 0.1 -> {          // 반박자로 들린 경우: 템포 유지, 위상만 보정
                mismatch = 0
                nudge(beatT)
            }
            abs(r - 0.5) < 0.05 -> mismatch = 0
            else -> if (++mismatch >= 5) {  // 곡이 바뀜 → 새 템포로 다시 잡기
                Beat.periodNs = newNs.toLong()
                Beat.anchorNs = beatT
                mismatch = 0
            }
        }
        weak = if (conf < 1.15f) weak + 1 else 0
        if (weak > 10) {
            Beat.locked = false
            agree = 0
        }
    }

    private fun nudge(beatT: Long) {
        val p = Beat.periodNs
        val a = Beat.anchorNs
        val k = Math.round((beatT - a).toDouble() / p)
        val pred = a + k * p
        val err = beatT - pred
        Beat.anchorNs = pred + (err * 0.25).toLong()
    }

    private fun fft() {
        var size = 2
        while (size <= n) {
            val half = size / 2
            val step = n / size
            var i = 0
            while (i < n) {
                for (j in 0 until half) {
                    val c = cosT[j * step]
                    val s = sinT[j * step]
                    val a = i + j
                    val b = a + half
                    val tr = re[b] * c - im[b] * s
                    val ti = re[b] * s + im[b] * c
                    re[b] = re[a] - tr
                    im[b] = im[a] - ti
                    re[a] += tr
                    im[a] += ti
                }
                i += size
            }
            size *= 2
        }
    }
}
